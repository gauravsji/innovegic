<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){
        parent::__construct();
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}

	public function register(){
		$this->load->model('registerModel');
		$data['user_list'] = $this->registerModel->getuserlist();
		$data['city_list'] = $this->registerModel->getcitylist();
		$data['state_list'] = $this->registerModel->getstatelist();
		$data['country_list'] = $this->registerModel->getcountrylist();
		$this->load->view('include/header');
		$this->load->view('register',$data);
		$this->load->view('include/footer');
	}

	public function userRegister() {
		$user_full_name = $_POST['user_full_name'];
        $user_address = $_POST['user_address'];
        $user_email = $_POST['user_email'];
        $user_city = $_POST['user_city'];
        $user_state = $_POST['user_state'];
        $user_country = $_POST['user_country'];
        $user_zipcode = $_POST['user_zipcode'];
        $user_phone_number = $_POST['user_phone_number'];
        $user_mobile_number = $_POST['user_mobile_number'];
        $data = array('user_full_name' => $user_full_name,
          'user_address' => $user_address,
          'user_email' => $user_email,
          'user_city' => $user_city,
          'user_state' => $user_state,
          'user_zipcode' => $user_zipcode,
          'user_phone_number' => $user_phone_number,
          'user_mobile_number' => $user_mobile_number,
      	);
		$result = $this->db->insert( 'user', $data );
		if( $result ) {
			redirect('');
		}
	}

	public function deleteuserDetail( $user_id ) {
		$this->db->where( 'user_id', $user_id );
		$result = $this->db->delete( 'user' );
		if( $result ) {
			redirect('');
		}
	}
}
