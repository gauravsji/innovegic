<?php

/**
* 
*/
class RegisterModel extends CI_Model
{

	public function getuserlist() {
		$this->db->select( '*' );
		$query = $this->db->get( 'user' );
		return $query->result();
	}
	
	public function getcitylist() {
		$this->db->select( '*' );
		$query = $this->db->get( 'tbl_cities' );
		return $query->result();
	}
	public function getstatelist() {
		$this->db->select( '*' );
		$query = $this->db->get( 'tbl_states' );
		return $query->result();
	}
	public function getcountrylist() {
		$this->db->select( '*' );
		$query = $this->db->get( 'tbl_countries' );
		return $query->result();
	}
}