</body>
    <footer>
        &copy 2021 test.com  | <a href="" target="_blank">by Gaurav Sharma</a>
    </footer>
    <!--FOOTER SECTION END  -->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="<?php echo base_url(); ?>assets/js/bootstrap.js"></script>
    <!-- SCROLLING SCRIPTS PLUGIN  -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.easing.min.js"></script>
    <!--  FANCYBOX PLUGIN -->
    <script src="<?php echo base_url(); ?>assets/js/source/jquery.fancybox.js"></script>
    <!-- ISOTOPE SCRIPTS -->
    <script src="<?php echo base_url(); ?>assets/js/jquery.isotope.js"></script>
     <!-- SCROLL ANIMATIONS  -->
    <script src="<?php echo base_url(); ?>assets/js/scrollReveal.js"></script>
    <!-- CUSTOM SCRIPTS   -->
    <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
</html>