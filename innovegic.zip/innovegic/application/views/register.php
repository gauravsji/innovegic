<div id="clients">
    <div class="overlay">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-12" data-scroll-reveal="enter from the bottom after 0.2s">
                    <h2>Register</h2>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CLIENTS SECTION END  -->
<div class="container" style="margin-bottom: 15px;">
    <div class="row" style="margin-top: 15px;">
        <div class="col-md-10">
            <h3>List Of User</h3>
        </div>
        <div class="col-md-2">
            <button type="button" class="btn btn-primary float-right" data-toggle="modal" data-target="#user_register">
                Create User
            </button>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
                <table class="table table-striped">
                    <thead> 
                        <tr>                        
                            <th><center>Full Name</center></th>
                            <th><center>Address</center></th>
                            <th><center>Email</center></th>
                            <th><center>City</center></th> 
                            <th><center>state</center></th>
                            <th><center>Country</center></th>
                            <th><center>Zip Code</th>
                            <th><center>Phone Number</center></th>
                            <th><center>Mobile Number</center></th>
                            <th><center>Action</center></th>
                        </tr>                                       
                    </thead>
                    <tbody>
                    <?php foreach ($user_list as $user_list ) { ?>
                        <tr>
                            <td><?php  echo $user_list->user_full_name ?></td>
                            <td><?php  echo $user_list->user_address ?></td>
                            <td><?php  echo $user_list->user_email ?></td>
                            <td><?php  echo $user_list->user_city ?></td>
                            <td><?php  echo $user_list->user_state ?></td>
                            <td><?php  echo $user_list->user_country ?></td>
                            <td><?php  echo $user_list->user_zipcode ?></td>
                            <td><?php  echo $user_list->user_phone_number ?></td>
                            <td><?php  echo $user_list->user_mobile_number ?></td>
                            <td>
                                <a href="<?php echo base_url(); ?>user/edit/<?php  echo $user_list->user_id ?>" class="btn btn-success btn-xs" title="Edit"><i class="fa fa-pencil"></i></a>
                                <a href="<?php echo base_url(); ?>user/delete/<?php  echo $user_list->user_id ?>" class="btn btn-danger btn-xs" title="Delete"><i class="fa fa-trash-o"></i></a>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
        </div>
    </div>
</div>
<!-- WORK SECTION END  -->

<!-- Modal -->
<div class="modal fade" id="user_register" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h3 class="modal-title" id="exampleModalLabel">Register Your Details<button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button></h3>
      </div>
        <div class="modal-body">
            <form id="frm_category" method="POST" action="<?php echo base_url(); ?>user/register" >
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" class="form-control" name="user_full_name" id="user_full_name" placeholder="Enter Full Name" required="true">
                    <span class="text-danger"><?php echo form_error('user_full_name'); ?></span>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" class="form-control" name="user_address" id="user_address" placeholder="Enter Address" required="true">
                    <span class="text-danger"><?php echo form_error('user_address'); ?></span>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" class="form-control" name="user_email" id="user_email" placeholder="Enter email" required="true">
                    <span class="text-danger"><?php echo form_error('user_email'); ?></span>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <select name="user_city" id="user_city" class="form-control">
                        <?php foreach ($city_list as $city_list ) { ?>
                        <option value="<?php  echo $city_list->name ?>"><?php  echo $city_list->name ?></option>
                        <?php }?>
                    </select>
                    <span class="text-danger"><?php echo form_error('user_city'); ?></span>
                </div>
                <div class="form-group">
                    <label>State</label>
                    <select name="user_state" id="user_state" class="form-control">
                        <?php foreach ($state_list as $state_list ) { ?>
                        <option value="<?php  echo $state_list->name ?>"><?php  echo $state_list->name ?></option>
                        <?php }?>
                    </select>
                    <span class="text-danger"><?php echo form_error('user_state'); ?></span>
                </div>
                <div class="form-group">
                    <label>Country</label>
                    <select name="user_country" id="user_country" class="form-control">
                        <?php foreach ($country_list as $country_list ) { ?>
                        <option value="<?php  echo $country_list->name ?>"><?php  echo $country_list->name ?></option>
                        <?php }?>
                    </select>
                    <span class="text-danger"><?php echo form_error('user_country'); ?></span>
                </div>
                <div class="form-group">
                    <label>Zip Code</label>
                    <input type="text" class="form-control" name="user_zipcode" id="user_zipcode" placeholder="Enter Zip Code" required="true">
                    <span class="text-danger"><?php echo form_error('user_zipcode'); ?></span>
                </div>
                <div class="form-group">
                    <label>Phone Number</label>
                    <input type="number" class="form-control" name="user_phone_number" id="user_phone_number" placeholder="Enter Phone Number" required="true">
                    <span class="text-danger"><?php echo form_error('user_phone_number'); ?></span>
                </div>
                <div class="form-group">
                    <label>Mobile</label>
                    <input type="number" class="form-control" name="user_mobile_number" id="user_mobile_number" placeholder="Enter Mobile No" required="true">
                    <span class="text-danger"><?php echo form_error('user_mobile_number'); ?></span>
                </div>
                <div class="error"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-danger set-bk-clr">Register</button>
                </div>
            </form>
        </div>
    </div>
  </div>
</div>